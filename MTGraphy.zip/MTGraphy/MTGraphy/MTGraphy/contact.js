document.getElementById('btnSubmit').addEventListener('click', submit)

function message() {
    alert('Your message has been sent!');
}